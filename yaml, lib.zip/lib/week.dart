import 'package:calender/todolist.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:syncfusion_flutter_calendar/calendar.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'day.dart';
import 'main.dart';
import 'meeting.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:ui';

class MyWeek extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Weekly',
      theme: ThemeData(
        primarySwatch: Colors.red,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: Weekly(),
    );
  }
}

class Weekly extends StatefulWidget {
  @override
  _WeeklyState createState() => _WeeklyState();
}

class _WeeklyState extends State<Weekly> {
  @override
  Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(
        title: Text('Weekly'),
        backgroundColor: Colors.amber,
        actions: [
          IconButton(icon: Icon(
            Icons.check_box_outlined,color: Colors.white,),
              onPressed: (){
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => MyAppTodo() ));
              }),
          IconButton(icon: Icon(Icons.list),
              onPressed: (){
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => MyDay() ));

              })
        ],
      ),
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.add, size: 40,),
        backgroundColor: Colors.amber,
        onPressed: (){
          Navigator.push(context,
              MaterialPageRoute(builder: (context) => AddMeeting() ));
        },
      ),
      body: Container(
        height: MediaQuery.of(context).size.height*3/4,
        child: SfCalendar(
          view: CalendarView.week,
          onTap: (CalendarTapDetails details) {

          },
          timeSlotViewSettings: TimeSlotViewSettings(
            timeInterval: const Duration(hours: 4),
          ),
          //showNavigationArrow: true,
          dataSource: MeetingDataSource(meetings),
          monthViewSettings: MonthViewSettings(
            showAgenda: true,
            agendaViewHeight: MediaQuery.of(context).size.height*1/11,
            //agenda는 동그라미로 나오게 하는 거
            appointmentDisplayCount: 2, //일정 몇개 보이게 할 건지
            appointmentDisplayMode: MonthAppointmentDisplayMode.appointment,
          ),
          viewHeaderHeight: 50,
          cellBorderColor: Colors.white,
          todayHighlightColor: Colors.orange,
          showDatePickerButton: true,
          selectionDecoration: BoxDecoration(
            color: Colors.transparent,
            border:
            Border.all(color: Colors.orange),
          ),
        ),
      ),

    );
  }
}
