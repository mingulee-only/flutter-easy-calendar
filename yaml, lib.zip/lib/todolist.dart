
import 'package:calender/main.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';

//https://github.com/FirebaseExtended/flutterfire/issues/2599
//오류:Plugin project :firebase_core_web not found. Please update settings.gradle.

DateTime startd = DateTime.now();
DateTime endd = DateTime.now();
String start = DateFormat('yyyy-MM-dd').format(startd);
String end = DateFormat('yyyy-MM-dd').format(endd);

class Todo {
  bool isDone;
  String title;

  Todo(this.title, {this.isDone = false});
}



class MyAppTodo extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'TodoList',
      theme: ThemeData(
        primarySwatch: Colors.red,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: TodoListPage(),
    );
  }
}

_TodoListPageState pageState;

class TodoListPage extends StatefulWidget {

  @override
  _TodoListPageState createState() {
    pageState = _TodoListPageState();
    return pageState;
  }
}

class _TodoListPageState extends State<TodoListPage> {

  var _todoController = TextEditingController();




  void dispose(){
    _todoController.dispose();
    super.dispose();
  }

  Widget _buildItemWidget(DocumentSnapshot doc){
    final todo = Todo(doc['title'], isDone: doc['isDone']);
    return ListTile(
      //onTap:() => _toggleTodo(doc),
      title: Row(
        children: [
          Checkbox(
            value: todo.isDone,
            onChanged: (value) {
              _toggleTodo(doc);
              setState(() {
                todo.isDone = value;
              });
            },
          ),
          Text(
            todo.title,
            style: todo.isDone? TextStyle(
              decoration: TextDecoration.lineThrough,
              fontStyle: FontStyle.italic,
            ) : null, //todo 아직 안 끝나면 적용 X
          ),
        ],
      ),
      trailing: IconButton(
        icon: Icon(Icons.delete_forever),
        onPressed: () => _deleteTodo(doc),    //todo 쓰레기통  클릭시 삭제되도록 수정
      ),
    );
  }

  void _addTodo(Todo todo) {
    Firestore.instance
        .collection('todo')
        .add({'title': todo.title, 'isDone': todo.isDone});
    _todoController.text = '';
  }


  void _deleteTodo(DocumentSnapshot doc) {
    Firestore.instance.collection('todo').document(doc.documentID)
        .delete();
  }

  void _toggleTodo(DocumentSnapshot doc){  //isdone으로 만들어줌 (이거를 tap에다가)
    Firestore.instance.collection('todo').document(doc.documentID).updateData({
      'isDone': !doc['isDone'],
    });
  }

  Widget addcheck(BuildContext context){
    return Scaffold(
      appBar: AppBar(
        title: SizedBox(height: 10,),
      ),
      body: Container(
        padding: const EdgeInsets.all(20.0),
          child: Column(
            children: [
              Align(
                alignment: Alignment.centerLeft,
                child: Text("할 일 추가하기",
                style: TextStyle(fontSize: 20),)
            ),
              TextField(
                decoration: InputDecoration(
                  hintText: '오늘 할 일을 적어주세요',
                ),
                controller: _todoController,
              ),
              Container(
                child: Row(
                  children: [
                    Expanded(
                      child: FlatButton(
                        child: Text('취소'),
                        onPressed: () async {
                          Navigator.pop(context);
                        },
                      ),
                    ),
                    Expanded(
                      child: FlatButton(
                        child: Text('확인'),
                        onPressed: () async {
                          setState(() {
                            _addTodo(Todo(_todoController.text));
                            Navigator.pop(context);
                          });
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ],
          )

      ),
    );

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('오늘의 할 일'),
        actions: [
          IconButton(icon: Icon(Icons.calendar_today),
              onPressed: (){
                Navigator.push(context, MaterialPageRoute(builder: (context) =>
                    MyApp()));
              }),
          IconButton(icon: Icon(Icons.add),
              onPressed: (){
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) =>
                        addcheck(context)));

              }),

        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: <Widget>[
            StreamBuilder<QuerySnapshot>(
              stream: Firestore.instance.collection('todo').snapshots(),
              builder: (context, snapshot) {
                if(!snapshot.hasData){
                  return CircularProgressIndicator();
                }
                final documents = snapshot.data.documents;
                return Expanded(
                  child: ListView(
                    children: documents
                        .map((doc) => _buildItemWidget(doc)).toList(),
                  ),
                );
              }
            )
          ],
        ),
      )
    );
  }
}
