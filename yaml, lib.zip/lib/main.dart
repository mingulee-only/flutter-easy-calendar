import 'package:calender/day.dart';
import 'package:calender/todolist.dart';
import 'package:calender/week.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:syncfusion_flutter_calendar/calendar.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'meeting.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:ui';



void main() {runApp(MyApp());}

final meetings = <Meeting>[];


class MyApp extends StatelessWidget {
  static const routeName = '/month';
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'calender',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: MyHomePage(title: 'Calender'),
    );
  }
}





class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);


  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}



class _MyHomePageState extends State<MyHomePage> {
  DocumentSnapshot doc;



  Future<List<Meeting>> _addDBList(DocumentSnapshot doc) async {
    final QuerySnapshot result = await Firestore.instance
        .collection('Meeting').getDocuments();

    final List<DocumentSnapshot> documents = result.documents;

    DateTime end = DateTime.fromMillisecondsSinceEpoch(doc['to']);
    DateTime start = DateTime.fromMillisecondsSinceEpoch(doc['from']);
    String backcolor = doc['background'];
    Color colorpick;

    if(backcolor == 'deepOrange'){
      colorpick = Colors.deepOrange;
    } else if(backcolor == 'deepPurple') {
      colorpick = Colors.deepPurple;
    } else if(backcolor == 'teal') {
      colorpick = Colors.teal;
    } else if(backcolor == 'purple') {
      colorpick = Colors.purple;
    } else if(backcolor == 'pink') {
      colorpick = Colors.pink;
    } else {
      colorpick = Colors.brown;
    }

    final getDB = Meeting(doc['eventName'], start, end, colorpick, doc['isAllDay']);

    meetings.add(getDB);

    return meetings;
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Month'),
        backgroundColor: Colors.amber,
        actions: [
          IconButton(icon: Icon(
            Icons.check_box_outlined,color: Colors.white,),
              onPressed: (){
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => MyAppTodo() ));
              }),
          IconButton(icon: Icon(Icons.list),
              onPressed: (){
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => MyWeek()));

              })
        ],
      ),
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.add, size: 40,),
        backgroundColor: Colors.amber,
        onPressed: (){
          Navigator.push(context,
              MaterialPageRoute(builder: (context) => AddMeeting() ));
        },
      ),
      body: Container(
        height: MediaQuery.of(context).size.height*3/4,
        child: SfCalendar(
          view: CalendarView.month,
          onTap: (CalendarTapDetails details) {
            },
          timeSlotViewSettings: TimeSlotViewSettings(
            timeInterval: const Duration(hours: 4),
          ),
          //showNavigationArrow: true,
          dataSource: MeetingDataSource(meetings),
          monthViewSettings: MonthViewSettings(
            showAgenda: true,
            agendaViewHeight: MediaQuery.of(context).size.height*1/11,
            //agenda는 동그라미로 나오게 하는 거
            appointmentDisplayCount: 2, //일정 몇개 보이게 할 건지
            appointmentDisplayMode: MonthAppointmentDisplayMode.appointment,
          ),
          viewHeaderHeight: 50,
          cellBorderColor: Colors.white,
          todayHighlightColor: Colors.orange,
          showDatePickerButton: true,
          selectionDecoration: BoxDecoration(
            color: Colors.transparent,
            border:
            Border.all(color: Colors.orange),
          ),
        ),
      ),

    );
  }

}

Widget viewCard(List<Meeting> list, DateTime selectedDate){
  BuildContext context;
  return Card(
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(16.0),
    ),
    elevation: 4.0,
    child: Container(
      width: MediaQuery.of(context).size.width *3/4,
      height: MediaQuery.of(context).size.height *2/4,
      child: Container(
        child:Column(
          children: [
            Text(DateFormat('yyyy년 MM월 dd일').format(selectedDate)),
          ],
        )
      ),
    ),
  );
}

////////////meeting_add



enum ColorState { deepOrange, deepPurple, teal, pink, purple, brown}


Color colorChoice = Colors.deepOrange;
SharedPreferences prefs;
//String startDate = DateFormat('yyyy-MM-dd\nHH:mm').format(DateTime.now());
//String endDate = DateFormat('yyyy-MM-dd\nHH:mm').format(DateTime.now());

DateTime startDay = DateTime.now();
DateTime endDay = startDay;
String start = DateFormat('yyyy-MM-dd').format(startDay);
String end = DateFormat('yyyy-MM-dd').format(endDay);





AddMeetingState pageStateMe;

class AddMeeting extends StatefulWidget {

  @override
  AddMeetingState createState() {
    pageStateMe = AddMeetingState();
    return pageStateMe;
  }
}

class AddMeetingState extends State<AddMeeting> {
  ColorState _colorstate = ColorState.deepOrange;
  SharedPreferences prefs;
  DocumentSnapshot doc;
  String strcolor = 'deepOrange';
  TextEditingController _titleCon = TextEditingController();

  TextStyle tsItem = const TextStyle(
      color: Colors.blueGrey, fontSize: 13, fontWeight: FontWeight.bold);
  TextStyle tsContent = const TextStyle(color: Colors.blueGrey, fontSize: 12);


  final _formkey = GlobalKey<FormState>();



  @override
  void dispose() {
    _titleCon.dispose();
    super.dispose();
  }

  List<Meeting> _addList(List<Meeting> meetings, String title,
      DateTime start, DateTime end, Color color) {
    final DateTime today = DateTime.now();
    final DateTime startTime =
    DateTime(today.year, today.month, today.day+1, 9, 0, 0);
    final endTime = startTime.add(const Duration(hours: 2));
    //meetings.add(Meeting('Conference', startTime, endTime, const Color(0xFF0F8644), false));
    meetings.add(Meeting(
        title, start, end, color, true));

    return meetings;
  }

  Future<DateTime> selectedDate(BuildContext context){
    Future<DateTime> dateSelect = showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2030,12,31),
    );

    return dateSelect;
  }


  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.orange,
        title: Text('일정 입력'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Form(
          key: _formkey,
          child: Column(
            children: <Widget>[
              SizedBox(
                height: 60,
                child: TextFormField(
                    style: TextStyle(fontSize: 20),
                    decoration: InputDecoration(
                      hintText: '일정 타이틀 입력',
                    ),
                    controller: _titleCon,
                    validator:(value) {
                      if (value
                          .trim()
                          .isEmpty) {
                        value = '내 일정';
                      }
                      return null;
                    }
                ),
              ),

              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      Container(
                          alignment: Alignment.centerLeft,
                          padding: const EdgeInsets.all(10.0),
                          child: Row(
                            children: [
                              Icon(Icons.access_time),
                              SizedBox(width: 20,),
                              Text(
                                "날짜 설정", style: TextStyle(fontSize: 20,),
                              ),
                            ],
                          )
                      ),
                      Row(
                        children: <Widget>[
                          Padding(padding: EdgeInsets.all(20.0)),
                          FlatButton(
                              onPressed: () {
                                Future<DateTime> startDate = showDatePicker(
                                  context: context,
                                  initialDate: startDay,
                                  firstDate: DateTime(2000),
                                  lastDate: DateTime(2030,12,31),
                                );
                                startDate.then((date) {
                                  setState(() {
                                    startDay = date;
                                    start = DateFormat('yyyy-MM-dd').format(startDay);
                                    endDay = startDay;
                                    end = DateFormat('yyyy-MM-dd').format(endDay);
                                  });
                                });
                              },
                              child: Text(
                                '$start',
                                textAlign: TextAlign.center,
                                style: TextStyle(color: Colors.black54, fontSize: 18.0),
                              )),
                          Icon(
                            Icons.chevron_right,
                            size: 35.0,
                          ),
                          FlatButton(
                              onPressed: () {
                                Future<DateTime> endDate = showDatePicker(
                                  context: context,
                                  initialDate: endDay,
                                  firstDate: DateTime(2000),
                                  lastDate: DateTime(2030,12,31),
                                );
                                endDate.then((date) {
                                  setState(() {
                                    endDay = date;
                                    end = DateFormat('yyyy-MM-dd').format(endDay);
                                  });
                                });
                              },
                              child: Text(
                                end,
                                textAlign: TextAlign.center,
                                style: TextStyle(color: Colors.black54, fontSize: 18.0),
                              )),
                        ],
                      ),
                      Container(
                          alignment: Alignment.centerLeft,
                          padding: const EdgeInsets.all(10.0),
                          child: Row(
                            children: [
                              Icon(Icons.create),
                              SizedBox(width: 20,),
                              Text(
                                "색상 선택", style: TextStyle(fontSize: 20,),
                              ),
                            ],
                          )
                      ),
                      Row(
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(5.0),
                            child: Container(
                              decoration:_colorstate == ColorState.deepOrange?
                              BoxDecoration(
                                  borderRadius: BorderRadius.circular(60),
                                  border: Border.all(width: 5, color: Colors.amberAccent)):null,
                              child: CircleAvatar(
                                child: FlatButton(
                                  onPressed: (){
                                    setState(() {
                                      _colorstate = ColorState.deepOrange;
                                      colorChoice = Colors.deepOrange;
                                      strcolor = 'deepOrange';
                                    });
                                  },
                                ),
                                backgroundColor: Colors.deepOrange,
                              ),
                            ),
                          ),

                          Padding(
                            padding: const EdgeInsets.all(5.0),
                            child: Container(
                              decoration:_colorstate == ColorState.deepPurple?
                              BoxDecoration(
                                  borderRadius: BorderRadius.circular(60),
                                  border: Border.all(width: 5, color: Colors.amberAccent)):null,
                              child: CircleAvatar(
                                child: FlatButton(
                                  onPressed: (){
                                    setState(() {
                                      _colorstate = ColorState.deepPurple;
                                      colorChoice = Colors.deepPurple;
                                      strcolor = 'deepPurple';
                                    });
                                  },
                                ),
                                backgroundColor: Colors.deepPurple,
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(5.0),
                            child: Container(
                              decoration:_colorstate == ColorState.teal?
                              BoxDecoration(
                                  borderRadius: BorderRadius.circular(60),
                                  border: Border.all(width: 5, color: Colors.amberAccent)):null,
                              child: CircleAvatar(
                                child: FlatButton(
                                  onPressed: (){
                                    setState(() {
                                      _colorstate = ColorState.teal;
                                      colorChoice = Colors.teal;
                                      strcolor = 'teal';
                                    });
                                  },
                                ),
                                backgroundColor: Colors.teal,
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(5.0),
                            child: Container(
                              decoration:_colorstate == ColorState.pink?
                              BoxDecoration(
                                  borderRadius: BorderRadius.circular(60),
                                  border: Border.all(width: 5, color: Colors.amberAccent)):null,
                              child: CircleAvatar(
                                child: FlatButton(
                                  onPressed: (){
                                    setState(() {
                                      _colorstate = ColorState.pink;
                                      colorChoice = Colors.pink;
                                      strcolor = 'pink';
                                    });
                                  },
                                ),
                                backgroundColor: Colors.pink,
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(5.0),
                            child: Container(
                              decoration:_colorstate == ColorState.purple?
                              BoxDecoration(
                                  borderRadius: BorderRadius.circular(60),
                                  border: Border.all(width: 5, color: Colors.amberAccent)):null,
                              child: CircleAvatar(
                                child: FlatButton(
                                  onPressed: (){
                                    setState(() {
                                      _colorstate = ColorState.purple;
                                      colorChoice = Colors.purple;
                                      strcolor = 'purple';
                                    });
                                  },
                                ),
                                backgroundColor: Colors.purple,
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(5.0),
                            child: Container(
                              decoration: _colorstate == ColorState.brown?
                              BoxDecoration(
                                  borderRadius: BorderRadius.circular(60),
                                  border: Border.all(width: 5, color: Colors.amberAccent)): null,
                              child: CircleAvatar(
                                child: FlatButton(
                                  onPressed: (){
                                    setState(() {
                                      _colorstate = ColorState.brown;
                                      colorChoice = Colors.brown;
                                      strcolor = 'brown';
                                    });
                                  },
                                ),
                                backgroundColor: Colors.brown,
                              ),
                            ),
                          ),

                        ],
                      )
                    ],
                  ),
                ),
              ),
              Container(
                child: Row(
                  children: [
                    Expanded(
                      child: FlatButton(
                        child: Text('취소'),
                        onPressed: () async {
                          Navigator.pop(context);
                        },
                      ),
                    ),
                    Expanded(
                      child: FlatButton(
                        child: Text('확인'),
                        onPressed: () async {
                          setState(() {
                              _addList(meetings, _titleCon.text.trim(), startDay, endDay, colorChoice);
                              Navigator.pop(context);
                          });
                        },
                      ),
                    ),
                  ],
                ),
              ),

            ],
          ),
        ),
      ),
    );

  }




}


