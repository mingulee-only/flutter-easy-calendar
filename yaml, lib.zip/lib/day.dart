import 'package:calender/todolist.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:syncfusion_flutter_calendar/calendar.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'main.dart';
import 'meeting.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:ui';


class MyDay extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Daily',
      theme: ThemeData(
        primarySwatch: Colors.red,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: Daily(),
    );
  }
}

class Daily extends StatefulWidget {
  @override
  _DailyState createState() => _DailyState();
}

class _DailyState extends State<Daily> {
  @override

  Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(
        title: Text('Daily'),
        backgroundColor: Colors.amber,
        actions: [
          IconButton(icon: Icon(
            Icons.check_box_outlined,color: Colors.white,),
              onPressed: (){
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => MyAppTodo() ));
              }),
          IconButton(icon: Icon(Icons.list),
              onPressed: (){
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => MyApp() ));
              }),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.add, size: 40,),
        backgroundColor: Colors.amber,
        onPressed: (){
          Navigator.popUntil(context, ModalRoute.withName('/month' ));
        },
      ),
      body: Container(
        height: MediaQuery.of(context).size.height*3/4,
        child: SfCalendar(
          view: CalendarView.timelineDay,
          onTap: (CalendarTapDetails details) {
            Navigator.push(context,
                MaterialPageRoute(builder: (context) => MyApp() ));
          },
          timeSlotViewSettings: TimeSlotViewSettings(
            timeInterval: const Duration(hours: 4),
          ),
          //showNavigationArrow: true,
          dataSource: MeetingDataSource(meetings),

          viewHeaderHeight: 50,
          cellBorderColor: Colors.white,
          todayHighlightColor: Colors.orange,
          showDatePickerButton: true,
          selectionDecoration: BoxDecoration(
            color: Colors.transparent,
            border:
            Border.all(color: Colors.orange),
          ),
        ),
      ),

    );
  }



}
